// api/cron/history.js — Vercel Cron (ทุก 10 นาที)
// เรียกจาก vercel.json: "0,10,20,30,40,50 * * * *"
const { fetchSensors } = require('../../lib/bot');
const { initializeApp, getApps } = require('firebase/app');
const { getDatabase, ref, push } = require('firebase/database');

let db;
function getDb() {
  if (!db) {
    const firebaseConfig = {
      apiKey:            process.env.FIREBASE_API_KEY,
      authDomain:        process.env.FIREBASE_AUTH_DOMAIN,
      databaseURL:       process.env.FIREBASE_DATABASE_URL,
      projectId:         process.env.FIREBASE_PROJECT_ID,
      storageBucket:     process.env.FIREBASE_STORAGE_BUCKET,
      messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
      appId:             process.env.FIREBASE_APP_ID,
    };
    const fbApp = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);
    db = getDatabase(fbApp);
  }
  return db;
}

module.exports = async (req, res) => {
  // Vercel cron ส่ง GET request — ตรวจสอบ secret
  const secret = req.headers['authorization'];
  if (secret !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const sensors = await fetchSensors();
    if (!sensors.length) return res.json({ ok: true, saved: 0 });

    const database = getDb();
    const ts = Date.now();
    await Promise.all(sensors.map(s => {
      const code = String(s.id).replace(/[\/\.#\$\[\]]/g, '-');
      return push(ref(database, `history/${code}`), { frc: s.frc, ts });
    }));

    console.log(`[Cron/history] ✅ บันทึก ${sensors.length} สถานี`);
    res.json({ ok: true, saved: sensors.length, ts });
  } catch (e) {
    console.error('[Cron/history] ❌', e.message);
    res.status(500).json({ error: e.message });
  }
};
