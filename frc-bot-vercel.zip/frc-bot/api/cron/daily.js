// api/cron/daily.js — Vercel Cron (08:00 เวลาไทย = 01:00 UTC)
const { handleBroadcastDaily, loadTargets } = require('../../lib/bot');

module.exports = async (req, res) => {
  const secret = req.headers['authorization'];
  if (secret !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  try {
    await loadTargets();
    await handleBroadcastDaily(null);
    console.log('[Cron/daily] ✅ ส่งสรุปวันเสร็จ');
    res.json({ ok: true });
  } catch (e) {
    console.error('[Cron/daily] ❌', e.message);
    res.status(500).json({ error: e.message });
  }
};
