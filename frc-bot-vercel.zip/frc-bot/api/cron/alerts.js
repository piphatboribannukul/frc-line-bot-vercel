// api/cron/alerts.js — Vercel Cron (ทุก 1 ชม.)
const { checkAlerts, loadTargets } = require('../../lib/bot');

module.exports = async (req, res) => {
  const secret = req.headers['authorization'];
  if (secret !== `Bearer ${process.env.CRON_SECRET}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  try {
    await loadTargets();
    await checkAlerts();
    console.log('[Cron/alerts] ✅ ตรวจ FRC alert เสร็จ');
    res.json({ ok: true });
  } catch (e) {
    console.error('[Cron/alerts] ❌', e.message);
    res.status(500).json({ error: e.message });
  }
};
