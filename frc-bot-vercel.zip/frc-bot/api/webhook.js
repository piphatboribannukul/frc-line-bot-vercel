// api/webhook.js — Vercel Serverless Function
const { app, loadTargets } = require('../lib/bot');

// โหลด targets เมื่อ cold start
loadTargets();

module.exports = app;
